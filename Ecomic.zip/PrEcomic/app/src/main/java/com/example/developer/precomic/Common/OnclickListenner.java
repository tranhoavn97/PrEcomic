package com.example.developer.precomic.Common;

import android.view.View;

public interface OnclickListenner {

    void Onclick(View view, int position);
}
