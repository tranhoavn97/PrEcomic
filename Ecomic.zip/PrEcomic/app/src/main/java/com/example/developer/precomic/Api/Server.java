package com.example.developer.precomic.Api;

public class Server {
    public  static String localhost="192.168.43.230";

    public final static String ServerName="http://"+ localhost +"/Ecomic/function.php";
}
