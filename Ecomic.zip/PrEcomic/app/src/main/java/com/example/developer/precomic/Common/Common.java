package com.example.developer.precomic.Common;

import com.example.developer.precomic.Object.Chapter;
import com.example.developer.precomic.Object.Ecomic;

import java.util.ArrayList;
import java.util.List;

public class Common {

    public static int Chapter_index=-1;
    public static Ecomic select_ecomic;
    public static Chapter select_chapter;
    public static List<Chapter> chapterList=new ArrayList<>();
}
