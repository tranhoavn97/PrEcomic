<?php
    require_once("config.php");

    //$myFunction= $_GET["myFunction"];
    $myFunction= $_POST["myFunction"];
    switch($myFunction)
    {
        case "LoadBanner":
        $myFunction();
        break;

        case "LoadManga":
        $myFunction();
        break;
        case "LoadChapter":
        $myFunction();
        break;
        case "LoadLink":
        $myFunction();
        break;

        case "Register":
        $myFunction();
        break;
        case "Login":
        $myFunction();
        break;
        

    }

    function Register()
    {
        // $conn lúc này kiểu như biến static;
        global $conn;
        if(isset($_POST["Fullname"]) || isset($_POST["Username"]) || isset($_POST["Password"]))
        {
            
            $Fullname = $_POST["Fullname"];
            $Username = $_POST["Username"];
            $Password=$_POST["Password"];
            
            $Password=hash('sha256',$Password);
            
            $query = "SELECT * FROM user WHERE Username='".$Username."'";
            $result = mysqli_query($conn, $query);
            if(mysqli_num_rows($result) >0)
            {
                
                echo "{ ketqua : false}";
            }
            else
            {
                
                $truyvan = "INSERT INTO user (Fullname,Username,Password) VALUE ('".$Fullname."','".$Username."','".$Password."')";
                if(mysqli_query($conn,$truyvan))
                {

                    echo "{ ketqua : true}";
                    
                }
                else
                {
                    echo "{ ketqua : false}".mysqli_error($conn);
                }
                
            }
        }
        
    }
    //end code
    function Login()
    {
        global $conn;

        if(isset($_POST["Username"]) || isset($_POST["Password"]))
        {
            $Username = $_POST["Username"];
            $Password = $_POST["Password"];

            $Password=hash('sha256',$Password);

            

            $truyvan = "SELECT * FROM user WHERE Username='".$Username."' AND Password='".$Password."'";
            $result=mysqli_query($conn,$truyvan);
            $countrow=mysqli_num_rows($result);
            if($result)
            {
                echo "{ketqua: true}";
            }
            else
            {
                echo "{ketqua: false}".mysqli_error($conn);
            }
                
        
        }
        
         

    }
    function LoadBanner()
    {
            global $conn;
            $truyvan = "SELECT * FROM banner";
            $ketqua = mysqli_query($conn,$truyvan);
            $chuoijson = array();
            echo "{";
                echo "\"LoadBanner\":";
            if($ketqua)
            {
                while($dong=mysqli_fetch_array($ketqua))
                {
                    // cach 1
                    //$chuoijson[]=$dong;
                    // cach 2
                    array_push($chuoijson, array("ID"=>$dong["ID"],"Link"=>"http://".$_SERVER['SERVER_NAME']."/Ecomic".$dong["Link"]));
                }
                echo json_encode($chuoijson,JSON_UNESCAPED_UNICODE);
            }
            echo "}";
    }

    function LoadManga()
    {
        global $conn;
        $truyvan = "SELECT * FROM manga";
        $ketqua = mysqli_query($conn,$truyvan);
        $chuoijson = array();
        echo "{";
            echo "\"DataManga\":";
        if($ketqua)
        {
            while($dong=mysqli_fetch_array($ketqua))
            {
                // cach 1
                $chuoijson[]=$dong;
                // cach 2
                
                
            }
            echo json_encode($chuoijson,JSON_UNESCAPED_UNICODE);
        }
        echo "}";
    }

    function LoadChapter()
    {
        global $conn;

        $chuoijson=array();
        
        
        if(isset($_POST["MangaID"]))
        {
            $MangaID=$_POST["MangaID"];
        }
        $query = "SELECT chapter.Name,chapter.ID FROM chapter,manga WHERE chapter.MangaID = ".$MangaID." AND manga.ID = chapter.MangaID";

        $result = mysqli_query($conn,$query);
        echo "{";
            echo "\"DataChapter\":";
        if($result)
        {
            
            while($dong=mysqli_fetch_array($result))
            {
                // cach 1
                $chuoijson[]=$dong;
                // cach 2   
                //array_push($chuoijson, array("Name"=>$dong["Name"]));
            
            }
            
            echo json_encode($chuoijson,JSON_UNESCAPED_UNICODE);
            
            
        }
        echo "}";
    }

    function LoadLink()
    {
        global $conn;

        $chuoijson=array();
        
        
        if(isset($_POST["ChapterID"]))
        {
            $ChapterID=$_POST["ChapterID"];
        }
        $query = "SELECT * FROM chapter,link WHERE link.ChapterID = ".$ChapterID." AND chapter.ID = link.ChapterID";

        $result = mysqli_query($conn,$query);
        echo "{";
            echo "\"DataLink\":";
        if($result)
        {
            
            while($dong=mysqli_fetch_array($result))
            {
                // cach 1
                $chuoijson[]=$dong;
                // cach 2   
                //array_push($chuoijson, array("Name"=>$dong["Name"]));
            
            }
            
            echo json_encode($chuoijson,JSON_UNESCAPED_UNICODE);
            
            
        }
        echo "}";
    }

?>
